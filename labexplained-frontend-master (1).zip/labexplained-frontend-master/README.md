
# build docker

``` 
docker build -t frontend:latest .
docker run -it -d -p 80:80 frontend:staging
```



# AWS Image Create-Push

```shell

docker build -t frontend:staging .
docker tag frontend:staging 405526781775.dkr.ecr.ca-central-1.amazonaws.com/frontend:staging
aws ecr get-login-password --region ca-central-1 | docker login --username AWS --password-stdin 405526781775.dkr.ecr.ca-central-1.amazonaws.com
docker push 405526781775.dkr.ecr.ca-central-1.amazonaws.com/frontend:staging

```


ENV REACT_APP_BACKEND_URL=http://lab-staging-backend-2137579077.ca-central-1.elb.amazonaws.com

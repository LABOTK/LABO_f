import React from "react";
import {Button, Nav, Navbar, NavbarBrand, NavItem,} from "reactstrap";
import "../Navbar/Navbar.css";
import {NavLink } from "react-router-dom";
import { useNavigate} from "react-router-dom"


function Navbars(args) {
const navigate =  useNavigate();
  return (
    <div>
      <Navbar {...args} color="light" className="myNavbar" >

        <NavbarBrand>
          <img
            alt="logo"
            src="/static/lab_Logo.png"
            style={{
              height: "30px",
              width: "30px",

            }}
          />
        </NavbarBrand>
        <Nav className="nav_ul" style={{display:"flex" , alignItems:"center" , justifyContent:"center"}} >
          <NavItem>
            <NavLink to="/about" className="custom-nav-item">
              About
            </NavLink>
          </NavItem>
          <NavItem>
            <NavLink to="/price" className="custom-nav-item">
              Price
            </NavLink>
          </NavItem>
          <NavItem>
            <NavLink to="/product" className="custom-nav-item">
              Product
            </NavLink>
          </NavItem>

          <NavItem>
              <Button onClick={()=>{ navigate("/login")}} color="dark" className="navBtn" >
                Login
              </Button>
          </NavItem>
          <NavItem>
              <Button onClick={()=>{ navigate("/signup")}} color="dark" className="navBtn">
                Sign Up
              </Button>
          </NavItem>
        </Nav>

      </Navbar>
    </div>
  );
}

export default Navbars;

// src/components/Sidebar.js
import React, {useCallback, useEffect, useState} from 'react';
import {Button} from "reactstrap"
import "../SideBar/Sidebar.css"
import {NavLink} from 'react-router-dom';
import CustomModal from "../Modal/Modal";

const Sidebar = ({  axiosInstance}  ) => {
    const [Useremail , setUseremail] = useState("");
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [subscription , setSubscription] = useState(null)

    function isActive(path) {
        return window.location.pathname === path;
    }


    const fetchUserEmail = useCallback(() => {
        axiosInstance.get('/api/account/profile/')
            .then((response) => {
                console.log(response.data.subscription, "response of Profile API");
                setSubscription(response.data.subscription);
                setUseremail(response.data.email.split("@")[0]);
            })
            .catch((error) => {
                console.error(error);
            });

    }, []);

    useEffect(() => {
        const isUserLoggedIn = localStorage.getItem('userLoggedIn');
        console.log(isUserLoggedIn , "IsuserLoggedIN")
        if (isUserLoggedIn && Useremail === "" ) {
            fetchUserEmail();
        }
    },  []);



    const logout = ()=>{
    window.location.href = "/logout";
  }
    const toggleModal = () => {
        setIsModalOpen(!isModalOpen);
    };


    return (
      <div className="sidebar mobileSidebar">
        <div className="profile">
          <div className="logo">
            <img src='/static/lab_Logo.png' alt='logo' width="40" height="40" />
          </div>
          <div className="username">
              <span style={{fontSize:"16px" , fontWeight:"bold"}}>{Useremail}</span>
          </div>
        </div>
          {subscription  === "free"?

          <div className="UpgradePlan">
                  <button className="upgradeBtn"  onClick={toggleModal}>Upgrade Plan</button>
          </div> :""
          }
          <CustomModal isOpen={isModalOpen} toggle={toggleModal} axiosInstance={axiosInstance}  />
          <NavLink to="/workspace" className="link"  >
            <div className={ isActive('/workspace') ? "activeWorkSpace mt-5" :"workSpaceContainer mt-5"}>
              <div className="detail">
                <span className="">M</span>
              </div>
              <div className="workspace">
                  <span className="workspanheading" style={{textDecoration:"none"}}>My WorkSpace</span>
              </div>
            </div>
          </NavLink>
        {/*  HistoryMain*/}
          <NavLink to="/history" className="link">
              <div className={ isActive('/history') ? "activehistoryContainer": "historyContainer mt-3"}>
                  <div className="detailHistory">
                      <span className="">H</span>
                  </div>
                  <div className="workspace">
                      <span  className="workspanheading">History</span>
                  </div>
              </div>
          </NavLink>
        <div className="logout">
          <Button style={{width:"70%"}} onClick={logout} color='secondary'>Logout</Button>
        </div>
      </div>
  );
};

export default Sidebar;

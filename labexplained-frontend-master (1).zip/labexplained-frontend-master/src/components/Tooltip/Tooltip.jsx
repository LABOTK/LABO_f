import React, {useState} from "react";
import PropTypes from "prop-types";
import "./Tooltip.css"; // Import your CSS file for Tooltip styling

const Tooltip = ({ text, children, tooltipClassName }) => {
    const [showTooltip, setShowTooltip] = useState(false);

    const handleMouseEnter = () => {
        setShowTooltip(true);
    };

    const handleMouseLeave = () => {
        setShowTooltip(false);
    };

    return (
        <div
            className="tooltip-container"
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
        >
            {children}
            {showTooltip && <div className={`custom-tooltip ${tooltipClassName}`}>{text}</div>}
        </div>
    );
};

Tooltip.propTypes = {
    text: PropTypes.string.isRequired,
    children: PropTypes.node.isRequired,
    tooltipClassName: PropTypes.string, // New prop     for custom class
};

export default Tooltip;

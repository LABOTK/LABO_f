import React, {useState} from "react"
import ReactAudioPlayer from "react-audio-player"
import {ReactComponent as BackIcon} from "../../icons/back-icon.svg";
import "../Processor/Processor.css"
import {toast} from "react-toastify";
import Toast from "../Toast/Toast";
import Spinner from "../Spinner/Spinner";

import {Card , CardBody } from "reactstrap";

const PodCastScript = ({podcastScript ,audioFileUrl ,setPodcastPortion , setPodcastScript , setAudioFileUrl , axiosInstance  , podCastId ,questions })=>{
    const [regeneratePoadcast , setRegeneratePodcast] = useState(false);
    const goBack = ()=>{

        setPodcastPortion(false);
        setPodcastScript([]);
        setAudioFileUrl(null)

    }
    const regenerateScript = () => {
        setRegeneratePodcast(true);
        const scriptQuestion = JSON.stringify(questions);
        const formData = new FormData();
        formData.append("podcast_id", podCastId);
        formData.append("questions", scriptQuestion);
        axiosInstance
            .post("/api/process/question", formData)
            .then((response) => {
                // Convert the blob to an object URL and store it
                setPodcastScript(response.data.podcast);
                const audioUrl = (response.data.audio_url);
                // const audioUrl = "https://file-examples.com/storage/fe235481fb64f1ca49a92b5/2017/11/file_example_MP3_700KB.mp3";
                // setScriptLoading(false);
                setPodcastPortion(true);
                setAudioFileUrl(audioUrl);
                setRegeneratePodcast(false);


            })
            .catch((error) =>{ console.error(error)
                const localScript  = JSON.parse(localStorage.getItem('localScript'));
                setPodcastScript(localScript);
                const localAudio   =  JSON.parse(localStorage.getItem('localaudio'));
                setAudioFileUrl(localAudio);
                setRegeneratePodcast(false)
                // setScriptLoading(false)
                setPodcastPortion(true);
                toast.error("Failed to get response try again");
            });

        // setAudioFileUrl("http://13.53.248.93/api/api/media/file/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmaWxlX3BhdGgiOiJhdWRpby82ZDU0MmExOS0zYzA5LTRlNTMtOWNhZS00MDRhMDA0MmFkODYvOTE5NDA3ZmUtMTYyOS00MWY2LTk3MTQtYTQ5NWE4NTY0NWVjLm1wMyIsInVzZXJfaWQiOiI2ZDU0MmExOS0zYzA5LTRlNTMtOWNhZS00MDRhMDA0MmFkODYiLCJleHBpcmVzIjoxNjkxNTcwMTczLjIwOTg0NCwidXVpZCI6ImE3YzZmNzRjLWE3NzUtNDEzMi1iZmNjLTRlMGE5OTZmNGZhNyJ9.Yq6tUOT-rs9veeOffV3SBlG-_ZJpoQF1erlfEOHOWzI")
        // setPodcastScript("Today we have a special guest on our show, Muhammad Lal Ahsan, who is a skilled React developer. We will be discussing his experiences and the web applications he has developed using React JS. Muhammad Lal Ahsan, thank you for joining us. Can you tell us about the web applications you have developed using React JS? Sure! I have developed several web applications using React JS. Some of the notable ones include a Food App that displays food items in categories, an inventory management system for a solar installation company, and a Shopify store merger system. That's impressive! Can you provide some more details about these applications? Certainly! The Food App I developed was a category display system where users can browse different food items based on their categories. For the solar installation company, I created a website using React JS that showcased their products and services. Lastly, the Shopify store merger system helped users manage their inventory, order products, and track shipments, all on a single platform. Muhammad Lal Ahsan has demonstrated his expertise in developing various web applications using React JS, ranging from a Food App to inventory management systems. His skills and experience in utilizing React JS has enabled him to create user-friendly and efficient applications. Thank you, Muhammad Lal Ahsan, for being our guest today. We appreciate you sharing your experiences and insights on developing web applications using React JS.")

    };


    return(
        <>
            <button className="back-button" onClick={goBack}>
                <BackIcon className="back-icon" />
            </button>

          <h1>Podcast Script</h1>

            {podcastScript &&
                (
                    <>
                        {regeneratePoadcast ?
                            <Spinner/>:
                            <>
                                <div className="glass-effect p-3  poadcastScriptContainer ">

                                            {podcastScript.map((podcast)=>(
                                                <Card>
                                                    <CardBody>
                                                        <span style={{fontWeight:"bold"}}>{podcast.speaker}</span>
                                                        <br/>
                                                        <span>{podcast.text}</span>

                                                    </CardBody>
                                                </Card>

                                            ))}
                                </div>
                                    {audioFileUrl && (
                                        <div className="audio-player  " >
                                        <ReactAudioPlayer className="audio" src={audioFileUrl} controls autoPlay />
                                     </div>
                                       )}
                            </>

                        }


                    </>
                )
            }
            <button onClick={regenerateScript} className="re-PodcastBtn button mt-3 mb-5">
                Regenerate Podcast
            </button>
            <Toast position="top-center" />
        </>

    )
}
export default PodCastScript

import React, {useEffect, useState} from "react";
import "../Processor/Processor.css";
import Spinner from "../Spinner/Spinner";
import FileUpload from "./FileUpload";
import Questions from "./Questions";
import PodCastScript from "./PodcastScript";
import Toast from "../Toast/Toast";

const ProcessorComponet = ({ axiosInstance }) => {
  // const [file, setFile] = useState(null);
  const [questions, setQuestions] = useState(null);
  // const [selectedQuestion, setSelectedQuestion] = useState(null);
  // const [newQuestion, setNewQuestion] = useState("");
  const [podCastId, setPodCastId] = useState(null);
  const [audioFileUrl, setAudioFileUrl] = useState(null);
  const [podcastScript, setPodcastScript] = useState([]);
  const [podcastLoading, setpodcastLoading] = useState(false);
  const [ScriptLoading , setScriptLoading] = useState(false);
  // const [editState ,  setEditState] = useState(false);
  // const [Id, setId] = useState(null);
  // const [isShown, setIsShown] = useState(false);
  // const [editShowBtn , setEditShowBtn] = useState(false);
  // const [addNewQuestion , setAddNewQuestion] = useState(false);
  // const [editId, setEditId] = useState(null);
  const [fileToken, setFileToken] = useState(null);
  // const [loader, setLoader] = useState(null);
  const [processOpenAi, setProcessOpenAi] = useState(false);
  // const [error, setError] = useState("");
  // const [regenerateQuestion , setRegenerateQuestion] = useState(false);
  // const [successFile , setSuccessFile] = useState("");
  const [podcastPortion , setPodcastPortion] = useState(false);
  const [subscription , setSubscription] = useState(null);





  useEffect(()=>{
    axiosInstance.get('/api/account/profile/')
        .then((response) => {
          // console.log(response.data.subscription, "response of Profile API")
          setSubscription(response.data.subscription);

        })
        .catch((error) => {
          console.error(error);
        });

  },[])

  return (

        <div className="Dropzone mx-3  mt-5 ">
          {
              !questions &&
                <FileUpload  axiosInstance = {axiosInstance}
                             setQuestions={setQuestions}
                             setpodcastLoading = {setpodcastLoading}
                             setPodCastId = {setPodCastId}
                             setFileToken = {setFileToken}
                             fileToken= {fileToken}
                             processOpenAi = {processOpenAi}
                             setProcessOpenAi = {setProcessOpenAi}
                />
          }




          {
            podcastLoading && !questions  ?
                <div className="mt-3">
                  <Spinner />
                </div>

                :
            questions &&  podcastScript.length === 0 ?(
              <Questions axiosInstance={axiosInstance}
                         questions={questions}
                         setQuestions={setQuestions}
                         setScriptLoading = {setScriptLoading}
                         setPodcastScript = {setPodcastScript}
                         podCastId = {podCastId}
                         setAudioFileUrl  = {setAudioFileUrl}
                         fileToken= {fileToken}
                         setPodCastId={setPodCastId}
                         setFileToken = {setFileToken}
                         setPodcastPortion = {setPodcastPortion}
                         subscription ={subscription}
              />
                ):""
          }

          {/*podCast Script*/}
          {
              ScriptLoading  ?
                  <div className="mt-2">
                      <>
                        <Spinner />
                      </>
                  </div>
                  :
                  podcastScript && podcastPortion ?

                    <PodCastScript
                        axiosInstance={axiosInstance}
                        podcastScript={podcastScript}
                        audioFileUrl = {audioFileUrl}
                        setPodcastPortion = {setPodcastPortion}
                        setPodcastScript = {setPodcastScript}
                        setAudioFileUrl  = {setAudioFileUrl}
                        podCastId = {podCastId}
                        questions={questions}
                    />
                      : ""
            }
          <Toast position="top-center" />
        </div>

  );
};

export default ProcessorComponet;

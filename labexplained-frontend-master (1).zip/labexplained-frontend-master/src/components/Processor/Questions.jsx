import React, {useCallback, useState} from "react"
import "./Processor.css"
import Spinner from "../Spinner/Spinner";
import {Card, CardBody, Input} from "reactstrap";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faAdd, faCheck, faPenToSquare, faTrash} from "@fortawesome/free-solid-svg-icons";
import {ReactComponent as BackIcon} from "../../icons/back-icon.svg";
import {toast} from "react-toastify";
import Toast from "../Toast/Toast";

const Questions = ({questions , setQuestions , axiosInstance , setScriptLoading ,setPodcastScript, setPodCastId , podCastId ,setAudioFileUrl , setPodcastPortion , fileToken  , setFileToken  ,subscription })=>{
    const [regenerateQuestion , setRegenerateQuestion] = useState(false);
    const [selectedQuestion, setSelectedQuestion] = useState(null);
    const [Id, setId] = useState(null);
    const [editId, setEditId] = useState(null);
    const [isShown, setIsShown] = useState(false);
    const [editState ,  setEditState] = useState(false);
    const [editShowBtn , setEditShowBtn] = useState(false);
    const [addNewQuestion , setAddNewQuestion] = useState(false);
    const [newQuestion, setNewQuestion] = useState("");
    // const [ScriptLoading , setScriptLoading] = useState(false);
    // const [podCastId, setPodCastId] = useState(null);
    // const [podcastScript, setPodcastScript] = useState("");
    // const [audioFileUrl, setAudioFileUrl] = useState(null);
    const goBack = ()=>{
        setQuestions(null);
        setFileToken(null)
        // setProcessOpenAi(true);
        const questionState = localStorage.getItem('QuestionState');
        if (questionState){
                 localStorage.setItem('QuestionState', JSON.stringify(false));
             }
        const fileUploader = localStorage.getItem('FileUploader');
        if (fileUploader) {
            localStorage.setItem('FileUploader', JSON.stringify(true));
        }
    }
    const handleMouseEnter = useCallback((index, id, question) => {
        setIsShown(true);
        setSelectedQuestion(question);
        setId(id);
    }, []);
    const handleMouseLeave = useCallback(() => {
        setIsShown(false) ;
        // setSelectedQuestion(null) ;
        setId(null);
    }, []);
    const handleInputChange = (event, id) => {
        const newQuestion = event.target.value;
        const updatedItems = [...questions];
        const quesIndex = questions.findIndex((ques) => ques.id === id);
        updatedItems[quesIndex] = {...questions[quesIndex], question: newQuestion,};
        setQuestions(updatedItems);
        setEditShowBtn(true);
    }
    const savedData = ()=>{
        setEditState(false);
        setId(null);
        setSelectedQuestion(null);
        setEditShowBtn(false);
    }
    const editQuestion = (id) => {
        setEditId(id)
        setEditState(true);

    }
    const SaveNewQuestion = () => {
        setAddNewQuestion(false);
        if (newQuestion.trim() === "") {
            toast.error('Please enter a question before clicking "Add Question".');
            return;
        }
        const {v4: uuidv4} = require('uuid');
        const newQuestionId = uuidv4();
        console.log(uuidv4());
        setQuestions([...questions, {id: newQuestionId, question: newQuestion}]);
        setNewQuestion("");
    };
    const addQuestionnsNew = ()=>{
        setAddNewQuestion(true);
    }
    const createScript = () => {
        setScriptLoading(true);
        const scriptQuestion = JSON.stringify(questions);
        const formData = new FormData();
        formData.append("podcast_id", podCastId);
        formData.append("questions", scriptQuestion);

        axiosInstance
            .post("/api/process/question", formData)
            .then((response) => {
                setPodcastScript(response.data.podcast);
                localStorage.setItem('localScript', JSON.stringify(response.data.podcast));
                const audioUrl = response.data.audio_url;
                localStorage.setItem('localaudio', JSON.stringify(response.data.audio_url));
                console.log(audioUrl)
                // const audioUrl = "https://file-examples.com/storage/fe235481fb64f1ca49a92b5/2017/11/file_example_MP3_700KB.mp3";
                setScriptLoading(false);
                setPodcastPortion(true);
                setAudioFileUrl(audioUrl);

                const questionState = localStorage.getItem('QuestionState');
                if (questionState){
                    localStorage.setItem('QuestionState', JSON.stringify(false));
                }

            })
            .catch((error) =>{ console.error(error)
                setScriptLoading(false)
                setPodcastPortion(false);
                toast.error("Failed to get response try again");
            });

        // setAudioFileUrl("http://13.53.248.93/api/api/media/file/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmaWxlX3BhdGgiOiJhdWRpby82ZDU0MmExOS0zYzA5LTRlNTMtOWNhZS00MDRhMDA0MmFkODYvOTE5NDA3ZmUtMTYyOS00MWY2LTk3MTQtYTQ5NWE4NTY0NWVjLm1wMyIsInVzZXJfaWQiOiI2ZDU0MmExOS0zYzA5LTRlNTMtOWNhZS00MDRhMDA0MmFkODYiLCJleHBpcmVzIjoxNjkxNTcwMTczLjIwOTg0NCwidXVpZCI6ImE3YzZmNzRjLWE3NzUtNDEzMi1iZmNjLTRlMGE5OTZmNGZhNyJ9.Yq6tUOT-rs9veeOffV3SBlG-_ZJpoQF1erlfEOHOWzI")
        // setPodcastScript("Today we have a special guest on our show, Muhammad Lal Ahsan, who is a skilled React developer. We will be discussing his experiences and the web applications he has developed using React JS. Muhammad Lal Ahsan, thank you for joining us. Can you tell us about the web applications you have developed using React JS? Sure! I have developed several web applications using React JS. Some of the notable ones include a Food App that displays food items in categories, an inventory management system for a solar installation company, and a Shopify store merger system. That's impressive! Can you provide some more details about these applications? Certainly! The Food App I developed was a category display system where users can browse different food items based on their categories. For the solar installation company, I created a website using React JS that showcased their products and services. Lastly, the Shopify store merger system helped users manage their inventory, order products, and track shipments, all on a single platform. Muhammad Lal Ahsan has demonstrated his expertise in developing various web applications using React JS, ranging from a Food App to inventory management systems. His skills and experience in utilizing React JS has enabled him to create user-friendly and efficient applications. Thank you, Muhammad Lal Ahsan, for being our guest today. We appreciate you sharing your experiences and insights on developing web applications using React JS.")

    };
    const regenerateQuestions = () => {
        setRegenerateQuestion(true)

        const formData = new FormData();
        formData.append("file_token", fileToken);
        formData.append("llm_id", 3.5 * 100);


        axiosInstance
            .post("/api/process/pdf", formData)
            .then((response) => {
                setQuestions(response.data.questions);
                setPodCastId(response.data.podcast_id);
                localStorage.setItem('localQuestions', JSON.stringify(response.data.questions));
                setRegenerateQuestion(false);
                const questionState = localStorage.getItem('QuestionState');
                const fileUploader = localStorage.getItem('FileUploader');
                if (fileUploader) {
                    localStorage.setItem('FileUploader', JSON.stringify(false));
                }
                console.log(questionState , "questionState");
            })
            .catch((error) => {
                setRegenerateQuestion(false)
                const getQuestion = JSON.parse(localStorage.getItem('localQuestions'));
                setQuestions(getQuestion);
                toast.error("Failed to regenerate questions try again")
                console.error(error);

            });


    };
    const deleteQuestion = (id) => {
      setQuestions(questions.filter((q, i) => q.id !== id));
      setSelectedQuestion(null);
    };
    console.log(subscription , "subscription");

    return(
        <>
            {
                questions && (
                    <div className="container">
                             <button className="back-button" onClick={goBack}>
                               <BackIcon className="back-icon" />
                             </button>

                             <h1 style={{ textAlign: "center" }}>Podcast Questions</h1>

                             {regenerateQuestion ?
                                 <div className="mt-4 mb-5">
                                   <Spinner/>
                                 </div>
                                 :
                                 questions.map((ques, index) => (
                                       <Card  style={{margin:"10px"}}
                                              key={index}
                                              className={selectedQuestion === ques.question ? "selected" : "list"}
                                              onMouseEnter={() => handleMouseEnter(index, ques.id, ques.question)}
                                              onMouseLeave={handleMouseLeave}
                                       >
                                         <CardBody >
                                           {/*    Edit Question Conditions */}
                                           {editId === ques.id && editState === true ?
                                               (
                                                   <>
                                                     <Input className="m-2 inputstyle"
                                                            type="text"
                                                            name="question"
                                                            onChange={(event) => handleInputChange(event, ques.id)}
                                                            value={ques.question}
                                                            onKeyDown={(e) => {
                                                              if (e.key === "Enter") {
                                                                savedData();
                                                              }
                                                            }}>
                                                     </Input>


                                                   </>)
                                               :
                                               (<>
                                                 {ques.question}
                                               </>)

                                           }
                                           {Id === ques.id && isShown ?

                                               subscription === "pro" ?
                                                   <>
                                                   <FontAwesomeIcon icon={faTrash} size="xl" style={{float: "right", color: "red"}}
                                                                    onClick={() => deleteQuestion(ques.id)} />

                                                   <FontAwesomeIcon icon={faPenToSquare} size="xl" color="danger"
                                                                    style={{float: "right", color: "blue"}} className="mx-4"
                                                                    onClick={() => editQuestion(ques.id)}/>
                                                   </>
                                                   :
                                                   <FontAwesomeIcon icon={faTrash} size="xl" style={{float: "right", color: "red"}}
                                               onClick={() => deleteQuestion(ques.id)} />


                                              :
                                               ""


                                           }
                                           {editId === ques.id && editState && editShowBtn ?
                                               <>
                                                 {/*<Tooltip text= "Save" tooltipClassName="custom-tooltip-style">*/}
                                                 <FontAwesomeIcon icon={faCheck} size="xl" id="save" color="danger"
                                                                  style={{float: "right", color: "green"}} className="mx-2" onClick={savedData}/>
                                                 {/*</Tooltip>*/}
                                               </>
                                               :""
                                           }


                                         </CardBody>
                                       </Card>
                                   ))}


                             {/*Add New Question */}
                             {addNewQuestion  ?
                                 <>
                                   {/*<div className="question-container mt-4">*/}
                                   <Card style={{margin:"10px"}}>
                                     <CardBody>

                                       <Input
                                           style={{width:"90%"}}
                                           type="text"
                                           value={newQuestion}
                                           onChange={(e) => setNewQuestion(e.target.value)}
                                           placeholder="Add a new question"
                                           className="question-input"
                                           onKeyDown={(e) => {
                                             if (e.key === "Enter") {
                                               SaveNewQuestion();
                                             }
                                           }}
                                       />


                                       <FontAwesomeIcon icon={faCheck}  size ="2xl" style={{float:"right"  , color:"green" }}  className="addnewSave" onClick={SaveNewQuestion} />

                                       {/*<FontAwesomeIcon icon={faCross}  size ="2xl" style={{float:"right"  , color:"red" }}  className="NoAddNewSave" onClick={NoSaveQuestion} />*/}

                                     </CardBody>
                                   </Card>


                                   {/*</div>*/}
                                 </>:""
                             }
                        {subscription === "pro" ?
                             <div className="d-flex justify-content-center">
                               <button   onClick={addQuestionnsNew} className="btn btn-primary addIconBtn">
                                 <FontAwesomeIcon icon={faAdd} className="mx-2" />
                                QUESTION
                               </button>
                             </div>
                            : ""
                        }
                             <button onClick={createScript} className="button m-2">
                               Create Podcast
                             </button>
                             <button onClick={regenerateQuestions} className="button m-2">
                             Regenerate Questions
                             </button>
                           </div>
                             )}

                       {/*</>*/}
            <Toast position="top-center" />

                 </>
        // </div>




        )
}
export default Questions
import React, {useCallback, useState} from 'react';
import {useDropzone} from "react-dropzone";
import "../Processor/Processor.css"
import Spinner from "../Spinner/Spinner";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faFilePdf, faTrash} from "@fortawesome/free-solid-svg-icons";
import {Button} from "reactstrap";
import {ReactComponent as BackIcon} from "../../icons/back-icon.svg";
import Toast from "../Toast/Toast";
import {toast} from "react-toastify";

const FileUpload = ({axiosInstance   , setpodcastLoading , setQuestions  ,setPodCastId , fileToken , setFileToken , setProcessOpenAi , processOpenAi})=>{
    const [file, setFile] = useState(null);
    // const [fileToken, setFileToken] = useState(null);
    const [loader, setLoader] = useState(null);
    // const [processOpenAi, setProcessOpenAi] = useState(false);
    const [error, setError] = useState("");
    // const [successFile , setSuccessFile] = useState("");
    const [regenerateQuestion , setRegenerateQuestion] = useState(false);
    // const [podCastId, setPodCastId] = useState(null);
    // const [questions, setQuestions] = useState(null);

    const onDrop = useCallback((acceptedFiles) => {
        setError("");
        setFile(acceptedFiles[0]);
        setLoader(true)
        const formData = new FormData();
        formData.append('file', acceptedFiles[0]);
        formData.append('name',  acceptedFiles[0].name);
        console.log("OnDrop is workking");

        axiosInstance.post("/api/media/file/upload/", formData)
            .then((response) => {
                console.log(response , "response");
                setFileToken(response.data.file_token);
                localStorage.setItem('fileToken', response.data.file_token);
                localStorage.setItem('FileUploader', JSON.stringify(true));
                toast.success("File uploaded successfully")
                setLoader(false);
                setProcessOpenAi(true);
                // toast.success("File Upload Successfully");

            })
            .catch((error) => {
               if ( error.response.data.error === "Failed to extract text from the PDF file."){
                   toast.error("Failed to extract text from the pdf file.")
                   setLoader(false);
                   setProcessOpenAi(false);
                   setError(error)
                   return;
               }

               else {
                   console.log(error)
                   setLoader(false);
                   setProcessOpenAi(false);
                   setError(error)
                   toast.error("Failed to upload file try again");
               }
            });

    }, []);


    const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });
    const getQuestions = () => {
        setRegenerateQuestion(true)
        setpodcastLoading(true);

        const formData = new FormData();
        formData.append("file_token", fileToken);
        formData.append("llm_id", 3.5 * 100);

        axiosInstance
            .post("/api/process/pdf", formData)
            .then((response) => {
                setQuestions(response.data.questions);
                setPodCastId(response.data.podcast_id);
                localStorage.setItem('localQuestions', JSON.stringify(response.data.questions));
                localStorage.setItem('QuestionState', JSON.stringify(true));
                const fileUploader = localStorage.getItem('FileUploader');
                if (fileUploader) {
                    localStorage.setItem('FileUploader', JSON.stringify(false));
                }
                setRegenerateQuestion(false);
                setProcessOpenAi(false);
                setpodcastLoading(false);
            })
            .catch((error) => {
                console.error(error);
                setpodcastLoading(false);
                toast.error("Failed to get response try again")
            });


        // setUuid("3bf4befa-56cc-4e47-9e58-ca03efd902a8")
        // setQuestions(["What web applications", " did Muhammad Lal Ahsan develop", " using React JS?",] )

    };
    const backToUploadFile = () => {
        setFileToken(null);
        setProcessOpenAi(false);
        const fileUploader = localStorage.getItem('FileUploader');
        // const questionState = localStorage.getItem('QuestionState');
        if (fileUploader) {
            localStorage.setItem('FileUploader', JSON.stringify(false));
        }
        // else if (questionState){
        //     localStorage.setItem('QuestionState', JSON.stringify(false));
        // }

    }

    return(
        <>
            {/*<div  className="Dropzone mt-5">*/}
                {!fileToken && (
                    <div className="container ">
                        {
                            loader ?
                                <>
                                    <h1 style={{textAlign: "center"}}>Upload PDF File </h1>
                                    <div className="Dropzone-box">
                                        <Spinner/>
                                    </div>
                                </>
                                :
                                <>
                                    <h1 style={{textAlign: "center"}}>Upload PDF File </h1>
                                    <div {...getRootProps()} className="Dropzone-box pointer ">
                                        <input {...getInputProps()} className="InputProcessor"/>
                                        {isDragActive || file ? (

                                                <p>
                                                    Drag and drop some files here, or click to select files{" "}
                                                    <FontAwesomeIcon icon={faFilePdf} size="lg"/>
                                                </p>
                                            ):
                                            <p>
                                                Drag and drop some files here{" "}
                                                <FontAwesomeIcon icon={faFilePdf} size="lg"/>
                                            </p>
                                        }

                                    </div>
                                </>
                        }
                    </div>
                )}

            {/*    Ai div  and File token respond*/}
                {processOpenAi && fileToken ? (
                    <>

                        <button className="back-button" onClick={backToUploadFile}>
                            <BackIcon className="back-icon"/>
                        </button>
                        {/*<h3 style={{color:"green"}} className="pt-4">{successFile}</h3>*/}
                        <div className=" container d-flex flex colum AiDiv">
                            <div  className="Dropzone-box pointer">
                                <FontAwesomeIcon icon={faFilePdf} size="2xl" style={{marginRight:"15px"}}/>
                                <p style={{paddingTop:"20px"}}>
                                    Selected file: <b>{file.name}</b>
                                </p>
                                <FontAwesomeIcon  onClick={backToUploadFile} icon={faTrash} size="xl" style={{marginLeft:"22px" , color:"red"}}   />
                            </div>
                        </div>
                        <Button className="buttonupload" onClick={getQuestions}>
                            {" "}
                            Process
                        </Button>
                    </>
                ) : ""}

            {/*<Toast position="top-center" />*/}
        </>
    )
}
export  default FileUpload
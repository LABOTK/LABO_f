import React, {useEffect, useState} from 'react';
import {Button, ButtonGroup, Card, Modal, ModalBody, ModalFooter, ModalHeader} from 'reactstrap';
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faCheck} from "@fortawesome/free-solid-svg-icons";
import "../Modal/Modal.css"

function CustomModal({toggle , isOpen , axiosInstance}) {
    const [interval , setInterval] = useState("monthly")
    const [ProplanPrice , setProplanPrice] = useState([]);

    const subscribe = (id)=>{
        const Subscribe_id  = id;
        console.log(id , "Id Subscribe");
        const formData = new FormData();
        formData.append("plan_id", Subscribe_id);
        axiosInstance.post("/api/payment/session/started/" , formData)
         .then((response) => {
             console.log(response.data.redirect);
             const redirectUrl   =  response.data.redirect;
             if(redirectUrl){
                 window.open(redirectUrl , '_blank' );
             }

         }).catch((error) => {
             console.log(error)
     })

    }
    const selectInterval =  (interval)=>{
        setInterval(interval);
        const formData  = new FormData();
        formData.append("interval", interval);
        axiosInstance.post(`/api/payment/plans` , formData)
            .then((response)=>{
                console.log(response.data);
                setProplanPrice(response.data.filter((plans)=>plans.name === 'Pro Plan'));
            }).catch((error) =>{
            console.log(error)
        })
    }
    useEffect(() => {
        selectInterval("monthly")
    }, []);



    return (
        <div>

            <Modal className="modalContainer" isOpen={isOpen} toggle={toggle} >

                <ModalHeader style={{textAlign:"center" , color:"black"}} toggle={toggle}>Price Plan</ModalHeader>

                <ModalBody >
                    <>
                        <h2 style={{textAlign:"center"}}>Select Plan</h2>
                        <div className="intervalBtns my-5">
                            <ButtonGroup className="BtnGroupInterval">
                                <Button
                                    color="primary"
                                    outline
                                    onClick={() => selectInterval("monthly")}
                                    active={interval === "monthly"}
                                >
                                    Monthly
                                </Button>
                                <Button
                                    color="primary"
                                    outline
                                    onClick={() => selectInterval("yearly")}
                                    active={interval === "yearly"}
                                >
                                    Yearly
                                </Button>
                            </ButtonGroup>

                        </div>
                        <div className="PriceCardContainer">
                        {
                            ProplanPrice?.map((data) => (
                                <Card className=" cardPrice mt-2 mx-3" >
                                    <div className="d-flex flex-column">

                                        <h5 className="p-4">{data.name}</h5>
                                        <h5 className="px-4">   {`$ ${data.price} / ${data.interval}`} </h5>
                                        <p className="pt-4" style={{fontWeight:"bold" , paddingLeft:"20px"}}>Highlights of plan features:</p>

                                        <p className="para_des pt-2">{data.features.map((des)=>(
                                            <ul>
                                                <li className="list-unstyled flex-column   ">  <FontAwesomeIcon className="px-1" icon={faCheck}  />{des.text}</li>
                                            </ul>
                                        ))}
                                        </p>
                                         <div className="d-flex justify-content-center" >
                                         <Button color="primary"  className="mb-4 subscribeBtn" onClick={()=>subscribe(data.id)}  >Subscribe</Button>
                                         </div>
                                    </div>
                                </Card>

                            ))
                        }
                        </div>
                    </>
                </ModalBody>
                <ModalFooter>

                    <Button color="secondary" onClick={toggle}>
                        Cancel
                    </Button>
                </ModalFooter>
            </Modal>
        </div>
    );
}

export default CustomModal;
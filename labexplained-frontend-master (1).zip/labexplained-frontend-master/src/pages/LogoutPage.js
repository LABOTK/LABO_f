import React from 'react';
import Spinner from "../components/Spinner/Spinner"

const LogoutPage = ({ axiosInstance }) => {

    // Clear tokens from local storage on logout
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    localStorage.setItem('userLoggedIn', 'false');
    axiosInstance.defaults.headers['Authorization'] = undefined;

    // Redirect to login page after logout
    window.location.href = '/login';

    return (
        <div className="container mt-5" >
            <>
            <h2 style={{textAlign:"center"}} >Loging Out</h2>
                <Spinner />
            </>
        </div>
    );
};

export default LogoutPage;

import React, {useEffect, useState} from "react";
import {useLocation, useParams} from "react-router-dom";
import Spinner from "../../components/Spinner/Spinner";
import "../Verify/verify.css";
import Navbars from "../../components/Navbar/Navbar";
import { useNavigate} from "react-router-dom";
import {Button} from "reactstrap";
const VerifyPage = ({ axiosInstance }) => {
  const location = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const { token } = useParams(); // Use useParams to get the 'token' parameter from the URL
  const [verificationStatus, setVerificationStatus] = useState({color:"green" , status: null});
  const navigate  = useNavigate();
  useEffect(() => {
    console.log(token , "token from URL");
    setIsLoading(true);
    const formData  =  new FormData();
    formData.append('verify_token' , token)

    axiosInstance
      .post("api/account/verify/email/", formData)
      .then((response) => {
        console.log(response);
        setVerificationStatus( {color:"green" ,  status :response.data.details });
        setIsLoading(false);
      })
      .catch((error) => {
        console.log(error);
        const errorMessage = error.response.data.error ;
        setVerificationStatus({color:"red" , status: errorMessage });
        setIsLoading(false);
      });

    // window.location.href = '/login';
  }, [location, axiosInstance, token]); // Include 'token' in the dependency array
  const redirectLogin = ()=>{
    navigate('/login');
  }
  return (
    <>
    <Navbars/>
      <div className="OuterEmailDiv">
        <h1 className="text-center ">Email Verification</h1>
        <div className="centered-container-verify">
          {isLoading  ? (
            <div>
              <Spinner />
            </div>
          ) : (
            <div>
              {verificationStatus.status ? (
                <div
                  style={{
                    fontSize: "35px",
                    fontWeight: "bolder",
                    color: verificationStatus.color,
                  }}
                >
                  {" "}
                  {verificationStatus.status}
                </div>
              ) : ""}
            </div>
          )}
        </div>
        <div className="verifytDiv">
          <Button style={{textAlign:"center" }} color="dark" className="redirectLogin" onClick={redirectLogin} >Return to Login</Button>
        </div>

      </div>
    </>
  );
};

export default VerifyPage;

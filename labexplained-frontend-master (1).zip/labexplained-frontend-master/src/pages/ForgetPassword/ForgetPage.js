import React, {useState} from "react";
import {Button, Input} from "reactstrap";
import Navbars from "../../components/Navbar/Navbar";
import Toast from "../../components/Toast/Toast"
import {toast} from "react-toastify";
import "./Forgetpassword.css"
import Spinner from "../../components/Spinner/Spinner"
import { useNavigate} from "react-router-dom";

const ForgetPage = ({ axiosInstance }) => {
  const [email, setEmail] = useState("");
  const [loading , setLoading] = useState(false);

  const handleEmailChange = (e) => {
    console.log(e.target.value)
    setEmail(e.target.value);
  };
  const  navigate = useNavigate();
  const handleResetPassword = () => {
    setLoading(true);
    if (email.trim() === "") {
      toast.error("Please enter your email.");
      setLoading(false)

      return;
    }

    axiosInstance
      .post("/api/account/forgot/password/", { email })
      .then((response) => {
        console.log(response);
        toast.success(response.data.message);
        setLoading(false);
      })
      .catch((error) => {
        toast.error(error.response?.data?.error || error.response?.data?.message);
        setLoading(false);
      });
  };

  return (
    <>
      <Navbars />
      <div className="outerContainer">
        <div className="centered-container-forget">
          <div className="content-forget">
            <h1>Reset your password</h1>

            <div className="d-flex mt-5 position-relative InputForgetDiv">
              <Input
                className="inputRadius inputStyle"
                id="exampleEmail"
                placeholder="Email"
                name="email"
                type="email"
                value={email}
                onChange={handleEmailChange}
              />
              <Button
                color="dark"
                className="buttonStyle"
                onClick={handleResetPassword}
              >
                Continue
              </Button>
            </div>
            <div className="my-4">
              {loading ?
                  <Spinner />
                  : ""
              }

            </div>

            <div className="mt-5">
              {/*<Link to="/login" style={{ textDecoration: "none" }}>*/}
                <Button style={{ textAlign:"center" }} color="dark" onClick={()=>{navigate("/login")}}> Return to Login </Button >
              {/**/}
              {/*</Link>*/}
            </div>
          </div>
        </div>
      </div>
      <Toast position="top-center" />

    </>

    // <div>
    //     <h2>Forgot Password</h2>
    //     <div style={{color: "red" }}>{message}</div>
    //     <div>
    //         <label>Email:</label>
    //         <input type="email" value={email} onChange={handleEmailChange} />
    //     </div>
    //     <button onClick={handleResetPassword}>Reset Password</button>
    // </div>
  );
};

export default ForgetPage;

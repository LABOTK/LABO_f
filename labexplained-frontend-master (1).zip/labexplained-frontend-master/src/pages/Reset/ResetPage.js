import React, {useState} from 'react';
import {Link, useParams} from 'react-router-dom';
import {Button, Input} from "reactstrap";
import "../Reset/ResetPage.css"
import Spinner from "../../components/Spinner/Spinner"
import Navbars from "../../components/Navbar/Navbar";
import Toast from "../../components/Toast/Toast"
import {toast} from "react-toastify"

const ResetPage = ({ axiosInstance }) => {
    const { token } = useParams();
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [loading , setLoading] = useState(false);

    const handlePasswordChange = (event) => {
        setPassword(event.target.value);
    };

    const handleConfirmPasswordChange = (event) => {
        setConfirmPassword(event.target.value);
    };

    const handleResetPassword = () => {
        if (!password || !confirmPassword) {
            toast.error('Please fill in both password fields.')

            return;
        } else if (password !== confirmPassword) {
            toast.error("Passwords don't match.");
            return;
        } else {
            // { reset_token: token, new_password: password }
            const formdata =  new FormData();
            formdata.append('reset_token',token)
            formdata.append('new_password',password);
            axiosInstance
                .post('api/account/reset/password/', formdata)
                .then((response) => {
                    console.log(response.data.message);
                    toast.success(response.data.message);
                    window.location.href = '/login';
                })
                .catch((error) => {
                    console.log(error.response.data.error);
                    // const errorMessage = error.response?.data?.error || error.response?.data?.message;
                    toast.error(error.response.data.error)
                });
        }
    };
    const redirectLogin = ()=>{
        window.location.href = "/login";
    }

    return (
        <>
            <Navbars/>
            <div className="outerContainer">
             <div className="centered-container-reset">
                 <div className="content-reset">
                     <h1>Reset Password</h1>
                     <div className="Input">
                         <Input
                             className="inputRadius inputStyle mt-5"
                             type="password"
                             placeholder="Enter password"
                             value={password}
                             onChange={handlePasswordChange}
                         />
                     </div>
                     <div className=" Input d-flex mt-4 position-relative" >
                         <Input
                             className="inputRadius inputStyle"
                             type="password"
                             placeholder="Confirm password"
                             value={confirmPassword}
                             onChange={handleConfirmPasswordChange}
                         />
                         <Button color="dark" className="buttonStyle" onClick={handleResetPassword}>
                             Continue
                         </Button>
                     </div>
                     <div className="redirectDiv mt-5">
                        <Button className="redirectLogin" color="dark" onClick={redirectLogin} >Return to Login</Button>
                     </div>

                 </div>
             </div>

            </div>
            <Toast position="top-center" />
        </>
    );
};

export default ResetPage;


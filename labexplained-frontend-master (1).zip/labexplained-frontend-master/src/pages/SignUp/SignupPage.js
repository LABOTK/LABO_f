import React, {useState} from "react";
// import { validate } from 'email-validator';
import {Button, Input} from "reactstrap";
import {Link} from "react-router-dom";
import Navbars from "../../components/Navbar/Navbar";
import "../SignUp/SignUp.css"
import Spinner from "../../components/Spinner/Spinner";
import { useNavigate} from "react-router-dom";
import Toast from "../../components/Toast/Toast"
import {toast} from "react-toastify";

const SignupPage = ({ axiosInstance }) => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const [error, setError] = useState("");
  const [signLoader , setSignLoader] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    console.log(e.target.value);
  };

  const handleSubmit = async (e) => {
    setSignLoader(true);
    console.log("Handle Submit is working")
    e.preventDefault();
    // setError("");

    try {
      const response = await axiosInstance.post("/api/account/register/", formData);
      console.log(response.data);
      setSignLoader(false)
      navigate("/login?signup=success");

      // window.location.href = "/login";

    } catch (err) {
      if (err.response && err.response.data) {
        // setError(err.response.data.error);
        console.log(err.response.data.error);
        toast.error(err.response.data.error);
        setSignLoader(false);
      }
    }
  };

  return (
    <>
    <Navbars/>
      <div className="OuterContainerSign">
        <div className="centered-containerSign">
            <div className="contentSign">
              <h1>Sign Up</h1>
              <div className="InputSignDiv">
                <Input
                  className="inputRadius inputStyle mt-5"
                  id="exampleEmail"
                  placeholder="Email"
                  name="email"
                  type="email"
                  value={formData.email}
                   onChange={handleChange}
                    required
                />
              </div>
              <div className="d-flex mt-4 position-relative InputSignDiv">
              <Input
                  className="inputRadius inputStyle"
                  id="examplePassword"
                  placeholder="Password"
                  name="password"
                  type="Password"
                  Value={formData.password}
                   onChange={handleChange}
                   required
                />
                <Button color="dark" className="buttonStyle" onClick={handleSubmit} >
                  Continue
                </Button>
              </div>

              { signLoader === true ? <div className="mt-4">
                <>
                  <Spinner />
                </>
              </div>: ""
              }
              {/*{error !== "" ? <div className="errorDiv" > {error}</div> :""}*/}
              <div className="mt-5" >
                <Link to="/login" style={{textDecoration:"none"}}>
                 <span style={{color:"black"}}>You already have an account? </span>Login in here.
                </Link>
              </div>
            </div>
          </div>
      </div>
      <Toast position="top-center" />
    </>


  );
};

export default SignupPage;

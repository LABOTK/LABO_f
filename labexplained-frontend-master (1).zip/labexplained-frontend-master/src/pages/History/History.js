import React, {useEffect, useState} from "react"
import Sidebar from "../../components/SideBar/Sidebar";
import "../History/History.css"
import {Card, CardBody} from "reactstrap"
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faFilePdf} from "@fortawesome/free-solid-svg-icons";
import ReactAudioPlayer from "react-audio-player"
// import {ReactComponent as BackIcon} from "../../icons/back-icon.svg";

const History = ({axiosInstance})=>{
    const [historyData , setHistoryData] = useState([]);
    const [dataFetched, setDataFetched] = useState(false);

    useEffect(() => {
        if (!dataFetched) { // Check if data has not been fetched yet
            axiosInstance.get(`/api/process/history`)
                .then((response) => {
                    console.log(response.data.results);
                    setHistoryData(response.data.results);
                    setDataFetched(true); // Set the flag to true after fetching data
                })
                .catch((error) => {
                    console.log(error);
                });
        }
    }, [dataFetched]);

    return (
        <>
            <div className="OuterHistoryContainer">

                <div className="sideBar_history">
                    <Sidebar  axiosInstance={axiosInstance} />
                </div>
                <div className="HistoryContainer" >
                    <h1 style={{textAlign:"center"}}>History Page</h1>
                    {
                        // historyData.length ===0 ? <h1 className="mt-5 historyEmpty" >No Uploaded file Yet</h1>:
                        historyData?.map((data) =>

                            <div className="cardContainer">
                                <Card className="my-2 historyCard">
                                    <CardBody>
                                        <div className="wholeCard">
                                            <div className="iconFile">
                                                <FontAwesomeIcon className=" fa-3x" style={{color: "#b20a03"}} icon={faFilePdf}  />
                                            </div>
                                            <div className="historyDetail">
                                                <div className="FileAndDate">
                                                    {/*<FontAwesomeIcon style={{color: "#b20a03"}} icon={faFilePdf}  size="lg"/>*/}
                                                    <span className="p-2">{data.article_file.name.substring(0, 30)}</span>
                                                    <span className="histortDate">Created at: {data.created_at} </span>
                                                    {/*<hr className="mt-4"/>*/}
                                                </div>
                                                {data.audio_file ? (
                                                    <div className="audioDiv mt-2">
                                                        <ReactAudioPlayer className="audioPlayer"  src= {data.audio_file.audio_url} controls  />
                                                    </div>
                                                ) : (
                                                    <p className="emptyfile mt-5 ">No Podcast Generated Yet</p>

                                                )}

                                            </div>

                                        </div>

                                    </CardBody>
                                </Card>
                            </div>
                        )

                    }
                </div>

            </div>
        </>
    )
}
export default History
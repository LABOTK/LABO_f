import React from 'react';
import Navbars from "../../components/Navbar/Navbar";
import "../About/About.css"
import {Col, Row} from "reactstrap"

const About  = ()=>{
    return(
        <>
            <Navbars/>
            <div className="outerContainer">
                 <h1 className="text-center">Who We Are</h1>
                <div className="d-flex  flex-column  container-fluid mt-5">
                    <Row>
                        <Col md="12">
                            <div className="container px-5 py-5 ParaDes" style={{textAlign:"center"}} >
                                <p className="ParaDes" >
                                    Lab Explained provides innovative tools to make academic content more engaging and
                                    accessible.
                                    <br/>
                                    Our platform allows students to quickly grasp key concepts from assigned readings by
                                    generating customized study guides and audio summaries. This saves time and boosts
                                    comprehension compared to traditional reading methods
                                    <br/>
                                    For professors, we offer a simple way to create podcasts showcasing their latest research.
                                    This expands the reach of academic work beyond journals to interested learners worldwide.
                                    Podcasts spotlight real-world applications, facilitating faster adoption of new discoveries by
                                    industry and society.
                                    <br/>
                                    At Lab Explained, our mission is to break down barriers to knowledge. We believe everyone
                                    should benefit from academic insights, not just those within academia. Our platform helps
                                    democratize learning by delivering digestible overviews of complex topics
                                    <br/>
                                    Join us in opening the doors of education wider!

                                </p>
                            </div>
                        </Col>
                        <Col md="12">
                            <div className="container imgdiv " style={{display:"flex"  , flexDirection:"row" , justifyContent:"center"}} >

                                <figure>
                                    <img
                                        src="/static/dummy1.png"
                                        alt="AboutPic"
                                        className="img-fluid"
                                        height="auto"
                                    />
                                </figure>
                            </div>
                        </Col>


                    </Row>
                </div>
            </div>
        </>
    )
}
export  default About
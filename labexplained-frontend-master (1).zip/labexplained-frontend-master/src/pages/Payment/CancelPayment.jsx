import React, {useEffect, useState} from 'react';
import {useLocation} from 'react-router-dom';
import {Button} from "reactstrap";

const CancelPayment = ()=>{
    const [Email , setEmail] = useState("");
    const [Details , setDetails] = useState("");
    const location = useLocation();
    const queryParams = new URLSearchParams(location.search);
    // Get the values of email and details
    const email = queryParams.get('email');
    const details = queryParams.get('details');
    useEffect(()=>{
        setEmail(email);
        setDetails(details);
    },[])
    // Console log the values
    console.log('Email:', email);
    console.log('Details:', details);
    const redirectFunc = ()=>{
        window.location.href = "/home";
    }
    return(
        <>
            <div className="contaiiner-fluid" style={{display:"flex" , justifyContent:"center" , alignItems:"center" ,width:"100vw" , height:"100vh"}} >
                <div className="contentCancel" style={{display:"flex" , flexDirection:"column" }}>
                    <h1 style={{color:"orange"}}>Cancel payment</h1>
                    <h2  style={{color:"" , textAlign:"center"}}>{Email}</h2>
                    <h3  style={{color:"" , textAlign:"center"}}>{Details}</h3>
                    <Button style={{alignItems:"center", justifyContent:"center" , width:"30%"}} onClick={redirectFunc}>Continue</Button>
                </div>
            </div>


        </>
    )

}
export  default CancelPayment
import React, {useEffect, useState} from "react";
import {Button, ButtonGroup, Card} from "reactstrap";
// import {PricingData} from ".//PricingData";
import Navbar from "../../components/Navbar/Navbar";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faCheck} from "@fortawesome/free-solid-svg-icons";
import ".//Pricing.css"

const Pricing  = ({axiosInstance})=>{
    const [interval, setInterval] = useState("monthly");
    const [plans , setPlans] = useState([]);

const selectInterval =  (interval)=>{
        setInterval(interval);
        const formData  = new FormData();
        formData.append("interval", interval);
        axiosInstance.post(`/api/payment/plans` , formData)
            .then((response)=>{
                setPlans(response.data);
            }).catch((error) =>{
                console.log(error)
            })
}
    useEffect(() => {
        selectInterval("monthly")
    }, []);
    return(
        <>
        <Navbar/>
            <div className="PriceContainer" >

                <div className=" container  ">
                    <h1 className="text-center">Pricing Plan</h1>

                        <h3  className="text-center pt-5"> Select Plan</h3>
                    <div className="intervalBtns my-5">
                        <ButtonGroup className="BtnGroupInterval">
                            <Button
                                color="primary"
                                outline
                                onClick={() => selectInterval("monthly")}
                                active={interval === "monthly"}
                            >
                                Monthly
                            </Button>
                            <Button
                                color="primary"
                                outline
                                onClick={() => selectInterval("yearly")}
                                active={interval === "yearly"}
                            >
                                Yearly
                            </Button>
                        </ButtonGroup>

                    </div>

                    {/*<Row>*/}
                        <div className="PriceCardContainer">
                            {
                                plans.map((data) => (
                                    <Card className=" mycard mt-5 mx-3" >
                                                        <div className="d-flex flex-column">
                                                            <h5 className="p-4">{data.name}</h5>
                                                            <h5 className="px-4">   {`$ ${data.price} / ${data.interval}`} </h5>

                                                            <p className="pt-4" style={{fontWeight:"bold" , paddingLeft:"20px"}}>Highlights of plan features:</p>

                                                            <p className="para_des pt-2">{data.features.map((des)=>(
                                                                <ul>
                                                                    <li className="list-unstyled flex-column   ">  <FontAwesomeIcon className="px-1" icon={faCheck}  />{des.text}</li>
                                                                </ul>
                                                                ))}
                                                            </p>
                                                        </div>
                                    </Card>

                                ))

                            }
                        </div>
                </div>
            </div>
        </>
    )
}
export default Pricing;









 const  monthlyData  = [
    {
        "id": "794266e1-1666-4417-b095-dc888a5b3460",
        "name": "Free Plan",
        "price": "0.00",
        "interval": "monthly",
        features: [
            {
                "name": "pdf-upload-free",
                "text": " Upload 10 PDFs for podcast."
            },
            {
                "name": "gpt-version-3",
                "text": "GPT-3.5"
            },
            {
                "name": "audio-quality-free",
                "text": "Good quality audio"
            },
            {
                "name": "customization-free",
                "text": "Limited customization options"
            },
            {
                "name": "usage-limits-free",
                "text": "Fair usage policy"
            }
        ]
    },
    {
        "id": "f2f3f562-9fbb-4b00-b6d0-9681b412a3a2",
        "name": "Pro Plan",
        "price": "9.00",
        "interval": "monthly",
        "features": [
            {
                "name": "pdf-upload-pro",
                "text": "Upload 100 PDFs for conversion."
            },
            {
                "name": "gpt-version-4",
                "text": "Upgraded to GPT-4"
            },
            {
                "name": "audio-quality-pro",
                "text": "Enhanced audio quality"
            },
            {
                "name": "customization-pro",
                "text": "More customization for podcasts"
            },
            {
                "name": "usage-limits-pro",
                "text": "Higher usage limits for pro users"
            }
        ]
    }
]

 const YearlyData  = [
     {
         "id": "f164a60c-04ce-4ff4-a121-cbc02bb1d8f0",
         "name": "Free Plan",
         "price": "0.00",
         "interval": "yearly",
         "features": [
             {
                 "name": "pdf-upload-free",
                 "text": " Upload 10 PDFs for podcast."
             },
             {
                 "name": "gpt-version-3",
                 "text": "GPT-3.5"
             },
             {
                 "name": "audio-quality-free",
                 "text": "Good quality audio"
             },
             {
                 "name": "customization-free",
                 "text": "Limited customization options"
             },
             {
                 "name": "usage-limits-free",
                 "text": "Fair usage policy"
             }
         ]
     },
     {
         "id": "e80a14f5-68d3-44bc-83cd-d4f5601755bc",
         "name": "Pro Plan",
         "price": "99.00",
         "interval": "yearly",
         "features": [
             {
                 "name": "pdf-upload-pro",
                 "text": "Upload 100 PDFs for conversion."
             },
             {
                 "name": "gpt-version-4",
                 "text": "Upgraded to GPT-4"
             },
             {
                 "name": "audio-quality-pro",
                 "text": "Enhanced audio quality"
             },
             {
                 "name": "customization-pro",
                 "text": "More customization for podcasts"
             },
             {
                 "name": "usage-limits-pro",
                 "text": "Higher usage limits for pro users"
             }
         ]
     }
 ]
 export  {YearlyData , monthlyData};
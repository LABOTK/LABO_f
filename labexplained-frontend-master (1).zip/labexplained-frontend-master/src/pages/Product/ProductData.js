export const productData = [
    {
        image: "/static/fileProductView.png",
        title: "Uplaod File",
        body: "",
    },


    {
        image: "/static/QuestionProductView.png",
        title: "Poadcast Questions",
        body: "",
    },
    {
        image: "/static/PoadcastProductView.png",
        title: "Script in Audio and text",
        body: "",
    },
]
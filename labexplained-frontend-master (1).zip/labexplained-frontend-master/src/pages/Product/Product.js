import React from "react";
import Navbar from "../../components/Navbar/Navbar";
import {Card, CardBody, CardImg, CardText, CardTitle, Col, Row} from "reactstrap";
import {productData} from "./ProductData"
import "../Product/Product.css"

const Product =()=>{

    return(
        <>
            <Navbar/>
            <div className="OuterProductContainer">
                <h1 className="text-center">Our Product</h1>
                <div className="container">
                <Row>
                    {productData.map((product)=>(

                        <Col md="4" >
                            <Card className="my-2" style={{alignItems:"center"}}>

                                <CardImg
                                    alt="Card image cap"
                                    src={product.image}
                                    style={{
                                        height: 300,
                                      width: 300
                                    }}
                                    top
                                    width="100%"

                                />

                                <CardBody>
                                    <CardTitle tag="h5">
                                        {product.title}
                                    </CardTitle>
                                    <CardText>
                                        {product.body}
                                    </CardText>

                                </CardBody>
                            </Card>
                        </Col>

                    ))}

                </Row>
                </div>
            </div>
        </>
    )
}
export  default  Product

import React from "react"
import Navbars from "../../components/Navbar/Navbar";
import "../LandingPage/Landing.css"

const LandingPage = ()=>{
    return(
        <>
            <Navbars/>
                <div className="OutertLanding">
                     <h1 className="h1_lab" >Welcome to Lab Explained</h1>
                    <h1 className="h1 "  >Article Podcast</h1>

                </div>
        </>
    )
}
export default LandingPage;
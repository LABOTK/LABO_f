import React, {useEffect, useState} from "react";
import {Link} from "react-router-dom";
import {Button, Input} from "reactstrap";
import Navbars from "../../components/Navbar/Navbar";
import "../Login/Login.css";
import Spinner from "../../components/Spinner/Spinner";
import Toast from "../../components/Toast/Toast";
import {toast} from "react-toastify";
import { useNavigate} from "react-router-dom";

const LoginPage = ({ axiosInstance }) => {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const navigate =  useNavigate();
  localStorage.setItem('IslogedIn', 'false');
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has("signup") && urlParams.get("signup") === "success") {
     toast.success("SignUp successfully");

      // Remove the signup parameter from the URL
      urlParams.delete("signup");
      const newURL = window.location.pathname + '?' + urlParams.toString();
      window.history.replaceState({}, document.title, newURL);
    }
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    console.log(e.target.value);
  };

  const handleSubmit = async (e) => {
    console.log("handleSubmit is working ");
    console.log(formData, "Form Data ");
    e.preventDefault();
    setError("");

    try {
      setIsLoading(true);
      axiosInstance.defaults.headers = {};
      axiosInstance.defaults.headers['Content-Type'] = 'multipart/form-data';
      const response = await axiosInstance.post("/api/account/login/", formData);
      console.log(response.data);

      // Save the tokens in local storage
      localStorage.setItem("access_token", response.data.access);
      localStorage.setItem("refresh_token", response.data.refresh);

      axiosInstance.defaults.headers[
        "Authorization"
      ] = `Bearer ${response.data.access}`;

      // Redirect to dropzone page on successful login

       navigate("/workspace") ;
      localStorage.setItem('userLoggedIn', 'true');
      setIsLoading(false);
    } catch (err) {
      if (err.response && err.response.data) {
        toast.error("Invalid credentials.")
        // setError("Invalid credentials.");
        setIsLoading(false);
      }
    }
  };

  return (
    <>
      <Navbars />
      <div className = "OuterContainer" >
        <div className="centered-container">
          <div className="content">
            <h1>Login</h1>
            <div className="Input">
              <Input
                className="inputRadius inputStyle mt-5"
                id="exampleEmail"
                placeholder="Email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
            {error && <div style={{ color: "red" }}>{error}</div>}
            <div className=" Input d-flex mt-4 position-relative">
              <Input
                className="inputRadius inputStyle"
                id="examplePassword"
                placeholder="Password"
                name="password"
                type="Password"
                Value={formData.password}
                onChange={handleChange}
                required
              />
              <Button
                color="dark"
                className="buttonStyle"
                onClick={handleSubmit}
              >
                Continue
              </Button>

              {isLoading === true ? (
                <div className="mt-5 loaderDiv">
                  <Spinner />
                </div>
              ) : (
                ""
              )}
            </div>
            <div className="forgetDiv">
              <Link to="/forget" style={{ textDecoration: "none" }}>
                <span style={{ color: "black" }}>Did you </span> forget your
                password ?
              </Link>
            </div>
            <div className="mt-5">
              <Link to="/signup" style={{ textDecoration: "none" }}>
                <span style={{ color: "black" }}>
                  You don't have an account?
                </span>{" "}
                Sign up
              </Link>
            </div>
          </div>
        </div>
      </div>
      <Toast position="top-center" />
    </>

  );
};

export default LoginPage;

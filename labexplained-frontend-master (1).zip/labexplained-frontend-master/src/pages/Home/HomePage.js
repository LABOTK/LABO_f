import React, {useEffect, useState} from "react";
import ProcessorComponet from "../../components/Processor/Processor";
import Sidebar from "../../components/SideBar/Sidebar"
import "../Home/Home.css"

const HomePage = ({ axiosInstance }) => {
  const screenWidth = window.innerWidth;

  const [accessToken, setAccessToken] = useState("");


  // useEffect(() => {
  //   axiosInstance.get("/api/account/profile/")
  //       .then((response) => {
  //         console.log(response.data.email);
  //         setUseremail(response.data.email);
  //       })
  //       .catch((error) => {
  //         console.error(error);
  //       });
  // }, [])
  useEffect(() => {
    // Check if access token is available in local storage
    const storedAccessToken = localStorage.getItem("access_token");
    if (storedAccessToken) {
      setAccessToken(storedAccessToken);
    } else {
      // Redirect to login page if access token is not available
      window.location.href = "/login";
    }
  }, []);

  useEffect(() => {
    // Schedule token refresh every 2 minutes
    const tokenRefreshInterval = setInterval(refreshAccessToken, 120000);

    // Clean up the interval on component unmount
    return () => clearInterval(tokenRefreshInterval);
  }, []);

  const refreshAccessToken = async () => {

    const refreshToken = localStorage.getItem("refresh_token");
    if (refreshToken) {
      try {
        const response = await axiosInstance.post("/api/account/login/refresh/", {refresh: refreshToken});
        const newAccessToken = response.data.access;
        setAccessToken(newAccessToken);
        localStorage.setItem("access_token", newAccessToken);
        // Store data in Local Storage
        localStorage.setItem('IslogedIn', 'true');

      }
      catch (err) {
        // Redirect to login page if token refresh fails
        console.log(err);
        window.location.href = "/";
        localStorage.removeItem("access_token");
        localStorage.removeItem("refresh_token");
      }
    } else {
      // Redirect to login page if refresh token is not available
      console.error(`Refresh token NOT found`);
      window.location.href = "/";
    }
  };


  return (
    <>
      <div className=" homeContainer">
        <div className="sideBar_container ">
          {screenWidth <= 765 ? null : <Sidebar axiosInstance={axiosInstance}  />}
          <Sidebar  axiosInstance={axiosInstance} />
        </div>
        <div className="Processor-Container">
          {accessToken && <ProcessorComponet axiosInstance={axiosInstance} />}
        </div>
      </div>
    </>
  );
};

export default HomePage;

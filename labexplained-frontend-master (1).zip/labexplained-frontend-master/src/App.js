import React from 'react';
import {BrowserRouter as Router, Route, Routes} from 'react-router-dom';
import SignupPage from "./pages/SignUp/SignupPage"
import LoginPage from "./pages/Login/LoginPage";
import LogoutPage from './pages/LogoutPage';
import HomePage from './pages/Home/HomePage';
import VerifyPage from './pages/Verify/VerifyPage';
import ResetPage from './pages/Reset/ResetPage';
import ForgetPage from './pages/ForgetPassword/ForgetPage';
import axios from 'axios';
import About from "./pages/About/About";
// import Sidebar from './components/SideBar/Sidebar';
import Pricing from "./pages/Payment/Pricing";
import Product from "../src/pages/Product/Product"
import History from "./pages/History/History";
import SuccessPayment from "./pages/Payment/SuccessPayment";
import FailPayment from "./pages/Payment/FailPayment";
import CancelPayment from "./pages/Payment/CancelPayment";
import LandingPage from "./pages/LandingPage/Landing";

function App() {

  const backendURL = process.env.REACT_APP_BACKEND_URL;
  const accessToken = localStorage.getItem('access_token');

  const axiosInstance = axios.create({
    baseURL: backendURL,
    headers: {
      'Authorization': `Bearer ${accessToken}`,
    },timeout:180000
  });

  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<LandingPage axiosInstance={axiosInstance} />} />
          <Route path="/login" element={<LoginPage axiosInstance={axiosInstance} />} />
          <Route path="/signup" element={<SignupPage axiosInstance={axiosInstance} />} />
          <Route path="/logout" element={<LogoutPage axiosInstance={axiosInstance} />} />
          <Route path="/forget" element={<ForgetPage axiosInstance={axiosInstance} />} />
          <Route path="/about" element={<About axiosInstance={axiosInstance} />} />
          <Route path="/workspace" element={<HomePage axiosInstance={axiosInstance}/>} />
          <Route path="/price" element={<Pricing axiosInstance={axiosInstance}/>} />
          <Route path="/verify/email/:token" element={<VerifyPage axiosInstance={axiosInstance} />} />
          <Route path="/reset/password/:token" element={<ResetPage axiosInstance={axiosInstance} />} />
          <Route path="/product" element={<Product axiosInstance={axiosInstance} />} />
          <Route path="/history" element={<History axiosInstance={axiosInstance} />} />
          <Route path="/payment/successful" element={<SuccessPayment axiosInstance={axiosInstance} />} />
          <Route path="/payment/error" element={<FailPayment axiosInstance={axiosInstance} />} />
          <Route path="/payment/cancelled" element={<CancelPayment axiosInstance={axiosInstance} />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;

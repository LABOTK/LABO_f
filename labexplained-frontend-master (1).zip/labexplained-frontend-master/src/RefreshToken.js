import axios from 'axios';

export const refreshAccessToken = async () => {

    const refreshToken = localStorage.getItem("refresh_token");
    if (refreshToken) {
        try {
            const response = await axios.post("/api/account/login/refresh/", {refresh: refreshToken});
            const newAccessToken = response.data.access;
            // setAccessToken(newAccessToken);
            localStorage.setItem("access_token", newAccessToken);
        }
        catch (err) {
            // Redirect to login page if token refresh fails
            console.log(err);
            window.location.href = "/";
            localStorage.removeItem("access_token");
            localStorage.removeItem("refresh_token");
        }
    } else {
        // Redirect to login page if refresh token is not available
        console.error(`Refresh token NOT found`);
        window.location.href = "/";
    }
};